import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import logo from "@/assets/logo.png";

const Footer = () => {
  return (
    <footer className="bg-accent text-accent-foreground">
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logo} alt="Cal Hills Medical Group logo" width={40} height={40} className="brightness-0 invert" />
              <div className="leading-tight">
                <span className="text-lg font-heading font-bold">Cal Hills</span>
                <span className="block text-xs tracking-widest uppercase opacity-70">Medical Group</span>
              </div>
            </div>
            <p className="text-sm opacity-80 leading-relaxed">
              Providing compassionate, high-quality healthcare to the Sacramento community. Your health is our priority.
            </p>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              {[
                { label: "Home", path: "/" },
                { label: "About Us", path: "/about" },
                { label: "Services", path: "/services" },
                { label: "Providers", path: "/providers" },
                { label: "Contact Us", path: "/contact" },
                { label: "Book Appointment", path: "/appointment" },
              ].map((item) => (
                <li key={item.path}>
                  <Link to={item.path} className="opacity-80 hover:opacity-100 hover:underline transition-opacity">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">Contact Info</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="h-4 w-4 mt-0.5 shrink-0 opacity-70" />
                <span className="opacity-80">2108 N ST #15550<br />Sacramento, CA 95816</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 shrink-0 opacity-70" />
                <a href="tel:9165551234" className="opacity-80 hover:opacity-100">(916) 555-1234</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0 opacity-70" />
                <a href="mailto:info@calhillsmedical.com" className="opacity-80 hover:opacity-100">info@calhillsmedical.com</a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold text-lg mb-4">Office Hours</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-3">
                <Clock className="h-4 w-4 shrink-0 opacity-70" />
                <span className="opacity-80">Monday – Friday</span>
              </li>
              <li className="pl-7 opacity-80">9:00 AM – 4:00 PM</li>
              <li className="pl-7 opacity-60 text-xs mt-1">Saturday & Sunday: Closed</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-accent-foreground/20 mt-12 pt-8 text-center text-sm opacity-60">
          © {new Date().getFullYear()} Cal Hills Medical Group. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
