import { useState } from "react";
import { Calendar, Clock, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";

const Appointment = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({ title: "Appointment Request Sent", description: "Our team will contact you to confirm your appointment." });
      (e.target as HTMLFormElement).reset();
    }, 1000);
  };

  return (
    <Layout>
      <section className="relative py-20 bg-accent text-accent-foreground">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-heading font-bold">Book an Appointment</h1>
          <p className="mt-4 text-lg opacity-85">Schedule a visit with one of our experienced care providers.</p>
        </div>
      </section>

      <section className="py-20">
        <div className="container max-w-2xl">
          <div className="flex items-center gap-4 mb-8 justify-center text-sm text-muted-foreground">
            <span className="flex items-center gap-2"><Calendar className="h-4 w-4 text-primary" /> Mon–Fri</span>
            <span className="flex items-center gap-2"><Clock className="h-4 w-4 text-primary" /> 9AM–4PM</span>
            <span className="flex items-center gap-2"><User className="h-4 w-4 text-primary" /> New Patients Welcome</span>
          </div>

          <div className="bg-card border rounded-xl p-8 shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">First Name *</label>
                  <Input required placeholder="John" />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Last Name *</label>
                  <Input required placeholder="Doe" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Email *</label>
                <Input type="email" required placeholder="john@example.com" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Phone *</label>
                <Input type="tel" required placeholder="(916) 555-1234" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Preferred Provider</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mitchell">Dr. James Mitchell, M.D.</SelectItem>
                    <SelectItem value="santos">Dr. Maria Santos, M.D.</SelectItem>
                    <SelectItem value="chen">Dr. Robert Chen, M.D.</SelectItem>
                    <SelectItem value="thompson">Sarah Thompson, NP</SelectItem>
                    <SelectItem value="any">No Preference</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Preferred Date</label>
                <Input type="date" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Reason for Visit</label>
                <Textarea placeholder="Please briefly describe the reason for your visit..." rows={4} />
              </div>
              <Button type="submit" disabled={loading} className="w-full cta-gradient text-primary-foreground font-semibold text-base py-6">
                {loading ? "Submitting..." : "Request Appointment"}
              </Button>
            </form>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Appointment;
