import { Link } from "react-router-dom";
import { Heart, Users, Award, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import teamImage from "@/assets/team-medical.jpg";
import aboutCareImage from "@/assets/about-care.jpg";

const values = [
  { icon: Heart, title: "Compassion", description: "We treat every patient with genuine care and empathy." },
  { icon: Award, title: "Excellence", description: "We maintain the highest standards in medical practice and patient outcomes." },
  { icon: Users, title: "Patient-Centered", description: "Your needs and preferences guide every decision we make." },
  { icon: Globe, title: "Community", description: "We serve the diverse Sacramento community with respect and dedication." },
];

const About = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative py-20 bg-accent text-accent-foreground">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-heading font-bold">We Do Well, Together</h1>
          <p className="mt-4 text-lg opacity-85 max-w-2xl">
            Cal Hills Medical Group elevates the patient-provider relationship by delivering tools, talent, and technology built to transform healthcare.
          </p>
          <Link to="/providers" className="inline-block mt-6">
            <Button variant="outline" className="border-accent-foreground/30 text-accent-foreground hover:bg-accent-foreground/10">Find a Provider</Button>
          </Link>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">About Cal Hills Medical Group</h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              Cal Hills Medical Group's mission is to elevate the health of our community through multiple medical specialties, providing excellent care delivered with wisdom, compassion, integrity, and a commitment to technology, education, and scientific inquiry.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Located at 2108 N ST #15550, Sacramento, CA 95816, we serve the greater Sacramento area with personalized and comprehensive medical services, ensuring each patient receives the attention they deserve.
            </p>
          </div>
          <div className="rounded-xl overflow-hidden shadow-lg">
            <img src={teamImage} alt="Cal Hills Medical Group team" loading="lazy" width={1280} height={864} className="w-full h-auto object-cover" />
          </div>
        </div>
      </section>

      {/* Your Health Your Way */}
      <section className="py-20 section-gradient">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="rounded-xl overflow-hidden shadow-lg">
            <img src={aboutCareImage} alt="Patient consultation" loading="lazy" width={1280} height={864} className="w-full h-auto object-cover" />
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">Your Health, Your Way</h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              Our patient satisfaction scores reflect our commitment to going above and beyond. We believe in patient-centered care — an evolving philosophy that empowers you and your family to be active participants in your healthcare journey.
            </p>
            <Link to="/appointment" className="inline-block mt-8">
              <Button className="cta-gradient text-primary-foreground font-semibold">Schedule An Appointment</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-center text-foreground mb-12">Our Core Values</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((v) => (
              <div key={v.title} className="bg-card border rounded-xl p-8 text-center hover:shadow-md transition-shadow">
                <div className="w-14 h-14 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-5">
                  <v.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-xl mb-3 text-foreground">{v.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{v.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
