import { Link } from "react-router-dom";
import { Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import doctor1 from "@/assets/doctor-1.jpg";
import doctor2 from "@/assets/doctor-2.jpg";
import doctor3 from "@/assets/doctor-3.jpg";
import doctor4 from "@/assets/doctor-4.jpg";

const providers = [
  { name: "Dr. James Mitchell, M.D.", specialty: "Internal Medicine", image: doctor1 },
  { name: "Dr. Maria Santos, M.D.", specialty: "Family Medicine", image: doctor2 },
  { name: "Dr. Robert Chen, M.D.", specialty: "Internal Medicine", image: doctor3 },
  { name: "Sarah Thompson, NP", specialty: "Nurse Practitioner", image: doctor4 },
];

const Providers = () => {
  return (
    <Layout>
      <section className="relative py-20 bg-accent text-accent-foreground">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-heading font-bold">Our Providers</h1>
          <p className="mt-4 text-lg opacity-85 max-w-2xl">
            Cal Hills Medical Group is dedicated to enhancing community well-being through a wide range of medical specialties and exceptional, compassionate care.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl font-heading font-bold text-foreground text-center mb-12">Doctors & Providers</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {providers.map((p) => (
              <div key={p.name} className="bg-card border rounded-xl overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-[4/5] overflow-hidden">
                  <img src={p.image} alt={p.name} loading="lazy" width={512} height={640} className="w-full h-full object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="font-heading font-semibold text-lg text-foreground">{p.name}</h3>
                  <p className="text-primary text-sm font-medium mt-1">{p.specialty}</p>
                  <div className="flex items-center gap-2 mt-3 text-sm text-muted-foreground">
                    <Phone className="h-3.5 w-3.5" /> (916) 555-1234
                  </div>
                  <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> Sacramento, CA
                  </div>
                  <Link to="/appointment" className="block mt-4">
                    <Button size="sm" className="w-full cta-gradient text-primary-foreground font-semibold">
                      Request Appointment
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Providers;
