import { Link } from "react-router-dom";
import { Activity, Syringe, HeartPulse, Stethoscope, Baby, Pill, Thermometer, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import clinicImage from "@/assets/clinic-interior.jpg";

const services = [
  { icon: HeartPulse, name: "Annual Wellness Exams" },
  { icon: Syringe, name: "Immunizations & Vaccines" },
  { icon: Activity, name: "Echocardiograms" },
  { icon: Stethoscope, name: "Ultrasound Imaging" },
  { icon: Baby, name: "Pediatric Care" },
  { icon: Pill, name: "Weight Management" },
  { icon: Thermometer, name: "Preventive Screenings" },
  { icon: Eye, name: "Vision & Hearing Tests" },
];

const Services = () => {
  return (
    <Layout>
      <section className="relative py-20 bg-accent text-accent-foreground">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-heading font-bold">Our Services</h1>
          <p className="mt-4 text-lg opacity-85 max-w-2xl">
            At Cal Hills Medical Group, primary care means remarkable care. Our providers deliver expert, evidence-based treatment worthy of your trust.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container">
          <h2 className="text-3xl font-heading font-bold text-foreground text-center mb-4">Medical Services</h2>
          <p className="text-center text-muted-foreground max-w-2xl mx-auto mb-12">
            From routine physicals to specialized diagnostics, we provide a full range of medical services to keep you and your family healthy.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((s) => (
              <div key={s.name} className="bg-card border rounded-xl p-6 flex items-center gap-4 hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <s.icon className="h-6 w-6 text-primary" />
                </div>
                <span className="font-medium text-foreground">{s.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 section-gradient">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">Complete Medical Care</h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              No matter what brings you in, we're connected by our commitment to your whole-person health. We provide a full team of medical professionals dedicated to making each visit easy and friendly.
            </p>
            <ul className="mt-6 space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-primary shrink-0" /> Care where, when and how you need it</li>
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-primary shrink-0" /> Same-day and next-day appointments</li>
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-primary shrink-0" /> Comprehensive preventive programs</li>
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-primary shrink-0" /> Coordination across specialties</li>
            </ul>
            <Link to="/providers" className="inline-block mt-8">
              <Button className="cta-gradient text-primary-foreground font-semibold">Find a Care Provider</Button>
            </Link>
          </div>
          <div className="rounded-xl overflow-hidden shadow-lg">
            <img src={clinicImage} alt="Modern medical clinic" loading="lazy" width={1280} height={864} className="w-full h-auto object-cover" />
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Services;
