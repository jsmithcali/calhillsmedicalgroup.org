import { Link } from "react-router-dom";
import { Heart, Shield, Users, Calendar, Stethoscope, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import heroImage from "@/assets/hero-medical.jpg";
import clinicImage from "@/assets/clinic-interior.jpg";
import aboutCareImage from "@/assets/about-care.jpg";

const features = [
  { icon: Shield, title: "Insurance Accepted", description: "We accept a wide range of health insurance plans to ensure you receive the care you need." },
  { icon: Stethoscope, title: "Our Services", description: "From preventive care to specialized treatments, we offer comprehensive medical services." },
  { icon: Calendar, title: "Easy Scheduling", description: "Book your appointment online or by phone — we make it simple to get the care you deserve." },
];

const Index = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative h-[600px] lg:h-[700px] overflow-hidden">
        <img src={heroImage} alt="Cal Hills Medical Group team" className="absolute inset-0 w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 hero-overlay" />
        <div className="relative container h-full flex items-center">
          <div className="max-w-2xl animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-primary-foreground leading-tight">
              Your Care When, Where, and How You Want It
            </h1>
            <p className="mt-6 text-lg text-primary-foreground/85 max-w-xl leading-relaxed">
              Connect with your healthcare team and enjoy a modern, seamless patient experience with Cal Hills Medical Group.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/appointment">
                <Button size="lg" className="cta-gradient text-primary-foreground font-semibold text-base px-8">
                  <Heart className="mr-2 h-5 w-5" /> Accepting New Patients
                </Button>
              </Link>
              <Link to="/services">
                <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground bg-primary-foreground/10 hover:bg-primary-foreground/20 font-semibold text-base px-8">
                  Our Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Tagline Banner */}
      <section className="cta-gradient py-6">
        <div className="container text-center">
          <h2 className="text-2xl md:text-3xl font-heading font-bold text-primary-foreground">
            Cal Hills Medical Group — The Care You Trust, Right Here
          </h2>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 section-gradient">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
              Prioritizing Your Well-being
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
              Cal Hills Medical Group is dedicated to delivering top-tier medical services while upholding the dignity and respect of each patient. Our team provides personalized, comprehensive treatment tailored to your unique needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div key={feature.title} className="bg-card rounded-xl p-8 text-center shadow-sm border hover:shadow-md transition-shadow">
                <div className="w-14 h-14 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-5">
                  <feature.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-heading font-semibold text-xl mb-3 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
                Complete Care is Right Around the Corner
              </h2>
              <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
                At Cal Hills Medical Group, we are committed to providing our patients with exceptional care and safeguarding their well-being. With experienced professionals and modern medical technology, we deliver healthcare solutions tailored to each individual.
              </p>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                We are proficient in multiple languages, including English, Spanish, and more — fostering meaningful connections across cultural boundaries.
              </p>
              <Link to="/about" className="inline-block mt-8">
                <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold">
                  Learn More About Us
                </Button>
              </Link>
            </div>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img src={aboutCareImage} alt="Compassionate patient care" loading="lazy" width={1280} height={864} className="w-full h-auto object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 section-gradient">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="rounded-xl overflow-hidden shadow-lg order-2 lg:order-1">
              <img src={clinicImage} alt="Cal Hills Medical Group clinic" loading="lazy" width={1280} height={864} className="w-full h-auto object-cover" />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">We Do Well, Together</h2>
              <p className="mt-6 text-muted-foreground leading-relaxed text-lg">
                You're more than a set of symptoms. We champion lifelong health and wellness, inside and outside the doctor's office. From preventive programs to complex care — we're here to support you every step of the way.
              </p>
              <div className="mt-8 flex items-center gap-6">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Mon–Fri: 9AM–4PM</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-5 w-5 text-primary" />
                  <span>Accepting New Patients</span>
                </div>
              </div>
              <Link to="/appointment" className="inline-block mt-8">
                <Button size="lg" className="cta-gradient text-primary-foreground font-semibold px-8">
                  Schedule an Appointment
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
